const express = require('express');
const path = require('path');
const app = express();
const port = 3000;

app.use(express.json());
app.use(express.static('public'));  // Serve static files from the 'public' folder

let items = [];  // In-memory storage for items

// Serve the main index HTML file
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// GET: Retrieve all items
app.get('/items', (req, res) => {
    res.json(items);
});

// GET: Retrieve a single item by ID
app.get('/item/:id', (req, res) => {
    const id = req.params.id;
    const item = items.find(i => i.id === id);

    if (item) {
        res.json(item);
    } else {
        res.status(404).json({ message: 'Item not found' });
    }
});

// PUT: Add a new item
app.put('/item', (req, res) => {
    const { id, name, description } = req.body;

    const existingItem = items.find((i) => i.id === id);
    if (existingItem) {
        return res.status(400).json({ message: 'Item with this ID already exists' });
    }

    const newItem = { id, name, description };
    items.push(newItem);

    res.status(201).json({ message: 'Item added successfully', item: newItem });
});

// PATCH: Update an existing item (using PATCH to partially update)
app.patch('/item/:id', (req, res) => {
    const id = req.params.id;
    const { name, description } = req.body;

    // Find the item by ID
    const itemIndex = items.findIndex((item) => item.id === id);

    if (itemIndex !== -1) {
        // Update the item's properties if provided
        if (name !== undefined) {
            items[itemIndex].name = name;
        }
        if (description !== undefined) {
            items[itemIndex].description = description;
        }

        return res.json({ message: 'Item updated successfully', item: items[itemIndex] });
    } else {
        return res.status(404).json({ message: 'Item not found' });
    }
});

// DELETE: Delete an item
app.delete('/item/:id', (req, res) => {
    const id = req.params.id; // ID is treated as a string
    const itemIndex = items.findIndex((i) => i.id === id);

    if (itemIndex !== -1) {
        items.splice(itemIndex, 1);  // Remove the item from the array
        res.json({ message: 'Item deleted successfully' });
    } else {
        res.status(404).json({ message: 'Item not found' });
    }
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
